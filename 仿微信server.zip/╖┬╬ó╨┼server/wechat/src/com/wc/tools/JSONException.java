package com.wc.tools;

public class JSONException extends Exception{
	
	public JSONException() {
		// TODO Auto-generated constructor stub
	}
	
	

	public JSONException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}



	public JSONException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}



	public JSONException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}



	/**
	 * 
	 */
	private static final long serialVersionUID = 2287830123397393374L;

}
